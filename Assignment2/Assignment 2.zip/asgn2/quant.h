
typedef struct
{ 
  int  dim;
  double**  mx;
}  Matrix;

typedef struct
{ 
  int  dim;
  double*  reg;
}  Register;

